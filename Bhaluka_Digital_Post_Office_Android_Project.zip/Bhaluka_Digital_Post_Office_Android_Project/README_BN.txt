ভালুকা ডিজিটাল পোস্ট অফিস — Android অ্যাপ প্রজেক্ট

এই ZIP-এ অ্যাপের সোর্স কোড আছে; সরাসরি APK ফাইল নেই। তবে GitHub Actions workflow যোগ করা হয়েছে, যাতে GitHub-এ আপলোড করলে ক্লাউডে APK তৈরি করা যায়—নিজের কম্পিউটারে Android Studio লাগবে না। মোবাইল থেকেই করা সম্ভব, তবে GitHub অ্যাকাউন্ট ও কয়েকটি ধাপ অনুসরণ করতে হবে।

অ্যাপের বিষয়বস্তু:
- Microsoft Word: File, Home, Insert, Layout, References, Mailings, Review, View
- Microsoft Excel: Salary Sheet, Result Sheet, Electricity Bill, Attendance Sheet, formula
- Microsoft PowerPoint: Presentation basics, design, transitions, animations, slide show
- সার্চ ও কুইজ
- শিক্ষামূলক বিষয়বস্তু অফলাইনে কাজ করে।

শুধু অ্যান্ড্রয়েড মোবাইল দিয়ে APK তৈরি করার পথ:
1. GitHub.com-এ অ্যাকাউন্ট খুলুন/লগইন করুন।
2. নতুন একটি repository তৈরি করুন, যেমন bhaluka-digital-post-office। Public বা Private—যেকোনোটি বেছে নিতে পারেন।
3. ZIP ফাইলটি আগে Extract করতে হবে। Extract করা ফোল্ডারের ভেতরের সব ফাইল ও .github ফোল্ডার repository-তে আপলোড করুন (ZIP ফাইলটিকে শুধু ZIP হিসেবেই আপলোড করবেন না)।
4. GitHub repository-তে Actions ট্যাব খুলুন। যদি workflow চালু করার অনুমতি চায়, সেটি Allow করুন।
5. বাম পাশে “Build Android APK” workflow নির্বাচন করে “Run workflow” চাপুন।
6. কাজ শেষ হলে সবুজ টিক দেখাবে। ওই workflow run খুলে নিচে Artifacts অংশে “Bhaluka-Digital-Post-Office-APK” ডাউনলোড করুন। এটি ZIP হিসেবে নামবে; মোবাইলে ZIP খুলে app-debug.apk বের করুন।
7. APK-তে চাপ দিয়ে Install করুন। Android যদি অনুমতি চায়, শুধু এই ফাইল/ব্যবহৃত অ্যাপের জন্য “Install unknown apps” অনুমতি দিন। ইনস্টল শেষে চাইলে অনুমতি বন্ধ করে দিন।

গুরুত্বপূর্ণ:
- GitHub-এর মেনু/মোবাইল লেআউট ভিন্ন হতে পারে। কোনো ধাপে আটকে গেলে স্ক্রিনশট পাঠান, আমি পরের ধাপ দেখাব।
- এটি প্রাথমিক শিক্ষামূলক অ্যাপ; Microsoft Office-এর মেনু সংস্করণভেদে আলাদা হতে পারে।
- বেতন, ফলাফল ও বিদ্যুৎ বিলের সূত্র নমুনা হিসেবে দেওয়া। বাস্তবে সংশ্লিষ্ট প্রতিষ্ঠানের নিয়ম ব্যবহার করুন।
- APK-টি debug build; Play Store-এ প্রকাশের জন্য উপযুক্ত signed release build নয়।
